# Issue Tracker API
Run:
1) Create DB in PostgreSQL: issuetracker
2) Update DATABASE_URL in app/database.py
3) pip install -r requirements.txt
4) uvicorn app.main:app --reload
