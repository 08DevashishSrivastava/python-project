from sqlalchemy.orm import Session
from . import models

def create_issue(db: Session, issue):
    db_issue = models.Issue(**issue.dict())
    db.add(db_issue)
    db.commit()
    db.refresh(db_issue)
    return db_issue

def get_issues(db: Session, skip=0, limit=10):
    return db.query(models.Issue).offset(skip).limit(limit).all()

def update_issue(db: Session, issue_id: int, data):
    issue = db.query(models.Issue).filter(models.Issue.id == issue_id).first()
    if not issue:
        return None
    if issue.version != data.version:
        raise Exception("Version conflict")
    for key, value in data.dict(exclude={"version"}).items():
        if value is not None:
            setattr(issue, key, value)
    issue.version += 1
    db.commit()
    db.refresh(issue)
    return issue
