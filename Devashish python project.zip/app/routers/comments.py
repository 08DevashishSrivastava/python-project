from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/issues/{id}/comments", tags=["Comments"])

@router.post("/")
def add_comment(id: int, comment: schemas.CommentCreate, db: Session = Depends(get_db)):
    if not comment.body.strip():
        raise HTTPException(status_code=400, detail="Comment cannot be empty")
    new = models.Comment(issue_id=id, body=comment.body, author=comment.author)
    db.add(new)
    db.commit()
    return new
