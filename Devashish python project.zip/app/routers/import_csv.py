import pandas as pd
from fastapi import APIRouter, UploadFile, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from .. import models

router = APIRouter(prefix="/issues", tags=["CSV"])

@router.post("/import")
def import_csv(file: UploadFile, db: Session = Depends(get_db)):
    df = pd.read_csv(file.file)
    success, failed = 0, 0
    for _, row in df.iterrows():
        try:
            issue = models.Issue(title=row['title'], description=row.get('description', ''))
            db.add(issue)
            success += 1
        except:
            failed += 1
    db.commit()
    return {"success": success, "failed": failed}
