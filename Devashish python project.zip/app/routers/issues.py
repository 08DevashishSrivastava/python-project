from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from .. import schemas, crud
from ..database import get_db

router = APIRouter(prefix="/issues", tags=["Issues"])

@router.post("/")
def create(issue: schemas.IssueCreate, db: Session = Depends(get_db)):
    return crud.create_issue(db, issue)

@router.get("/")
def list_issues(db: Session = Depends(get_db)):
    return crud.get_issues(db)

@router.patch("/{id}")
def update(id: int, data: schemas.IssueUpdate, db: Session = Depends(get_db)):
    try:
        return crud.update_issue(db, id, data)
    except Exception as e:
        raise HTTPException(status_code=409, detail=str(e))
