from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/labels", tags=["Labels"])

@router.post("/")
def create(label: schemas.LabelSchema, db: Session = Depends(get_db)):
    new = models.Label(name=label.name)
    db.add(new)
    db.commit()
    return new
