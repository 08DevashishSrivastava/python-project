from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from ..database import get_db
from .. import models

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.get("/top-assignees")
def top_assignees(db: Session = Depends(get_db)):
    return db.query(models.Issue.assignee_id, func.count()).group_by(models.Issue.assignee_id).all()

@router.get("/latency")
def avg_latency(db: Session = Depends(get_db)):
    return db.query(func.avg(models.Issue.resolved_at - models.Issue.created_at)).scalar()
