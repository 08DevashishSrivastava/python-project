from pydantic import BaseModel
from typing import Optional

class IssueCreate(BaseModel):
    title: str
    description: Optional[str] = None
    assignee_id: Optional[int] = None

class IssueUpdate(BaseModel):
    title: Optional[str]
    description: Optional[str]
    status: Optional[str]
    version: int

class CommentCreate(BaseModel):
    body: str
    author: str

class LabelSchema(BaseModel):
    name: str

class IssueOut(BaseModel):
    id: int
    title: str
    status: str
    version: int

    class Config:
        orm_mode = True
